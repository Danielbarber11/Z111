import firebase from "firebase/compat/app";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyDu9xJlDhzA5TfBsakrQj21Ybupjcu7KDo",
  authDomain: "verdantconnect-wp8dj.firebaseapp.com",
  databaseURL: "https://verdantconnect-wp8dj-default-rtdb.firebaseio.com",
  projectId: "verdantconnect-wp8dj",
  storageBucket: "verdantconnect-wp8dj.firebasestorage.app",
  messagingSenderId: "530048230107",
  appId: "1:530048230107:web:e400c941adc4d4f829e2fe"
};

// Fix: Use compat initialization to resolve "no exported member initializeApp" error in some environments
const app = firebase.initializeApp(firebaseConfig);

// Fix: Cast app to any to bridge compat App type with modular SDK functions
export const auth = getAuth(app as any);
export const database = getDatabase(app as any);